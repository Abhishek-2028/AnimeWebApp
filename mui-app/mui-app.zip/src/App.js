import React from "react"
import AnimeSearch from "./components/AnimeSearch";



function App() {

 


  return (
    <>
      <div className="App">
        <AnimeSearch/>  
      </div>
    </>
  );
}

export default App;

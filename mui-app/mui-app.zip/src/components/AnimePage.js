import React from 'react'

const AnimePage = () => {
  return (
    <div>
      
    </div>
  )
}

export default AnimePage

import React, { useEffect, useState } from 'react'
import SearchRoundedIcon from '@mui/icons-material/SearchRounded';
import { Divider } from '@mui/material';
import AnimeBar from './AnimeBar';
import axios from "axios";

const AnimeSearch = () => {

    const[animeData,setAnimeData]=useState([]);

        
    const ApiFetch =async() =>{
 
       await axios.get('https://api.jikan.moe/v4/characters?page=0&limit=15&q=&order_by=favorites&sort=desc')
       .then(
         (res)=>{
           setAnimeData(res.data.data)
           console.log(res.data);
         }
       ).catch(
         (err)=>console.log(err)
       )
 
    }
 
    useEffect(()=>{
     ApiFetch()
    },[])

    return (
        <>

            <div style={{ display: 'flex', justifyContent: 'center', flexDirection: 'column', alignItems: 'center', width: '100%' }}>
                <h1>Search Anime Characters</h1>

                <div style={{ display: "flex", width: '40%', justifyContent: 'center', border: '2px solid black', borderRadius: '15px', padding: '4px' }}>
                    <SearchRoundedIcon />
                    <Divider orientation='vertical' flexItem style={{ background: 'black', marginLeft: '5px', border: '1px solid black' }} />
                    <input style={{ width: '90%', fontSize: '22px', border: 'none', outline: 'none', marginLeft: '5px' }} />
                </div>
            </div>
            <Divider style={{marginTop:'70px',background:'black',border:'1px solid black'}}/>
             <AnimeBar animeData={animeData}/> 

        </>
    )
}

export default AnimeSearch

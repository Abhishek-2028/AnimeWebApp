import { Box,Stack,Divider } from '@mui/material'
import { Typography } from 'antd';
import React from 'react'

const AnimeBar = ({animeData}) => {

    console.log("anime",animeData);

  return (
    <div style={{display:'flex',justifyContent:'center',alignItems:'center'}}>
      <Stack direction='row' sx={{border:'2px solid black',p:1,mt:7,width:'85%'}}>

       <Box component='div' style={{width:'90%'}}>
        <Stack direction='row' spacing={4}>
            <Box component='img' src={animeData[0]?.images.jpg.image_url} height={100} width={80}/>
            <Box>
              <Stack spacing={1}>
                <Box  display="flex" mt={-2.5}>
                  <Typography component="h3">{animeData[0]?.name}
                  </Typography>
                  </Box>
                <Box display='flex' gap={3} flexWrap='wrap' >
                  {
                    animeData[0]?.nicknames.map((data)=>(
                        <Box  sx={{background:'grey',borderRadius:'12px',padding:'5px'}} ><Typography>{data}</Typography></Box>
                    ))

                  }
                  </Box>
              </Stack>
            </Box>
        </Stack>
       </Box>
        <Divider sx={{border:'1px solid black'}} orientation='vertical' flexItem />
       <Box component='div' style={{width:'10%'}}>jii</Box>

      </Stack>
    </div>
  )
}

export default AnimeBar
